// ==========================
// Registration & Login Logic
// ==========================

// Store users locally (for demo purpose, not secure!)
function registerUser() {
  const username = document.getElementById("regUsername").value.trim();
  const email = document.getElementById("regEmail").value.trim();
  const password = document.getElementById("regPassword").value.trim();

  if (username && email && password) {
    localStorage.setItem("user", JSON.stringify({ username, email, password }));
    alert("✅ Registration successful! Please login.");
    document.querySelector(".container").classList.remove("right-panel-active");
  } else {
    alert("⚠ Please fill all fields!");
  }
}

function loginUser() {
  const username = document.getElementById("loginUsername").value.trim();
  const password = document.getElementById("loginPassword").value.trim();
  const user = JSON.parse(localStorage.getItem("user"));

  if (user && user.username === username && user.password === password) {
    alert("✅ Login successful!");
    document.querySelector(".container").style.display = "none";
    document.getElementById("libraryPage").style.display = "block";
  } else {
    alert("❌ Invalid credentials! Try again.");
  }
}

// Toggle Register/Login panels
document.getElementById("signUp").addEventListener("click", () => {
  document.querySelector(".container").classList.add("right-panel-active");
});
document.getElementById("signIn").addEventListener("click", () => {
  document.querySelector(".container").classList.remove("right-panel-active");
});

// ==========================
// Story Library + API Fetch
// ==========================
const API_URL = "https://68b84911b71540504327be04.mockapi.io/api/v1/stories";

// Fetch all stories from API
async function fetchStories() {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error("Failed to fetch");
    return await response.json();
  } catch (err) {
    console.error("API Error:", err);
    return [];
  }
}

// Search stories from API
async function filterStories() {
  const input = document.getElementById("searchInput").value.toLowerCase();
  const storyList = document.getElementById("genreStoryList");
  storyList.innerHTML = "";

  const stories = await fetchStories();

  const filtered = stories.filter(
    (s) =>
      s.title.toLowerCase().includes(input) ||
      s.content.toLowerCase().includes(input)
  );

  if (filtered.length > 0) {
    filtered.forEach((story) => {
      const div = document.createElement("div");
      div.className = "story-card";
      div.textContent = story.title;
      div.onclick = () => openStory(story);
      storyList.appendChild(div);
    });
    document.getElementById("libraryPage").style.display = "none";
    document.getElementById("genreStories").style.display = "block";
    document.getElementById("genreTitle").textContent = "Search Results";
  } else {
    storyList.textContent = "⚠ No stories found in API.";
  }
}

// ==========================
// Story Navigation Functions
// ==========================
async function toggleStory(card) {
  const genre = card.innerText.split("✔")[0].trim();
  document.getElementById("libraryPage").style.display = "none";
  document.getElementById("genreStories").style.display = "block";
  document.getElementById("genreTitle").textContent = genre;

  const listContainer = document.getElementById("genreStoryList");
  listContainer.innerHTML = "Loading stories...";

  const stories = await fetchStories();

  // Filter by genre
  const filtered = stories.filter(s => s.genre === genre);

  listContainer.innerHTML = "";
  if (filtered.length > 0) {
    filtered.forEach(story => {
      const div = document.createElement("div");
      div.className = "story-card";
      div.textContent = story.title;
      div.onclick = () => openStory(story);
      listContainer.appendChild(div);
    });
  } else {
    listContainer.textContent = "⚠ No stories found in this genre.";
  }
}

let currentPage = 0;
let storyPages = [];

// Open story with multiple pages
function openStory(story) {
  document.getElementById("genreStories").style.display = "none";
  document.getElementById("storyReader").style.display = "block";
  document.getElementById("storyTitle").textContent = story.title;

  // Split story into paragraphs (pages)
  storyPages = story.content.split("\n\n"); // double line break = new page
  currentPage = 0;
  showPage();
}

// Show current page
function showPage() {
  if (storyPages.length > 0) {
    document.getElementById("storyContent").innerHTML = `<p>${storyPages[currentPage]}</p>`;
    document.getElementById("pageNumber").textContent = 
      `Page ${currentPage + 1} of ${storyPages.length}`;
  }
}

// Go to next page
function nextPage() {
  if (currentPage < storyPages.length - 1) {
    currentPage++;
    showPage();
  }
}

// Go to previous page
function prevPage() {
  if (currentPage > 0) {
    currentPage--;
    showPage();
  }
}

function goBackToLibrary() {
  document.getElementById("genreStories").style.display = "none";
  document.getElementById("libraryPage").style.display = "block";
}

function goBackToGenre() {
  document.getElementById("storyReader").style.display = "none";
  document.getElementById("genreStories").style.display = "block";
}

// ==========================
// Story Narration (TTS)
// ==========================
const synth = window.speechSynthesis;
let sentences = [];
let currentIndex = 0; // which sentence we are on
let utterance = null;

function speakStory() {
  if (synth.speaking) synth.cancel();

  const content = document.getElementById("storyContent").textContent.trim();
  if (!content) return alert("No story content!");

  // Split story into sentences (simple split on period)
  sentences = content.split(/([.!?])\s+/).filter(s => s.trim() !== "");
  currentIndex = 0;
  speakNextSentence();
}

function speakNextSentence() {
  if (currentIndex >= sentences.length) return;

  utterance = new SpeechSynthesisUtterance(sentences[currentIndex]);
  utterance.rate = 1;
  utterance.pitch = 1;

  utterance.onend = function() {
    currentIndex++;
    speakNextSentence(); // automatically go to next sentence
  };

  synth.speak(utterance);
}

// Stop narration
function stopStory() {
  if (synth.speaking) synth.cancel(); // stops current utterance
}

// Resume narration
function resumeStory() {
  if (currentIndex >= sentences.length) return; // already finished
  speakNextSentence();
}
